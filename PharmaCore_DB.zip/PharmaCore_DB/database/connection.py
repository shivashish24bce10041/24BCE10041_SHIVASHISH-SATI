from pymongo import MongoClient                 # pymongo is a lib that help the python to talk to MongoDB

client = MongoClient("mongodb://localhost:27017")   # This create the connection with mongodb 
#                        |          |       |
#                 mongodb protocol  |    mongodb default port 
#                                   |
#                                 my mac 

db = client["pharmacore_db"]                # MongoDB stores data in the database 



