from pydantic import BaseModel

class FundingGrant(BaseModel):
    grant_name: str
    funding_company_id: str
    molecule_id: str
    amount: float
    grant_date: str
    