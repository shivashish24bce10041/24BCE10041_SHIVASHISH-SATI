from pydantic import BaseModel

class AdverseEvent(BaseModel):
    molecule_id: str
    event_name: str
    severity: str
    reported_date: str
    description: str