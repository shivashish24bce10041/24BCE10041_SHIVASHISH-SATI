from pydantic import BaseModel

class ResearchTeam(BaseModel):
    team_name: str
    department: str
    lead_scientist_id: str
    project_name: str