from pydantic import BaseModel          # Importing basemodel from pydantic as it can validate the input  

class Molecule(BaseModel):              # Making the class name Molecule and its object 
    name :str
    molecule_type :str
    disease_target: str
    discovery_date: str
    status: str
    description: str