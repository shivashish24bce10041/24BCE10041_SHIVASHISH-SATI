from pydantic import BaseModel

class RegulatoryBody(BaseModel):
    body_name: str
    country: str
    approval_status: str
    contact_email: str