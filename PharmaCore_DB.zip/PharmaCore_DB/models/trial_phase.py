from pydantic import BaseModel

class TrialPhase(BaseModel):
    molecule_id: str
    phase_name: str
    start_date: str
    end_date: str
    status: str