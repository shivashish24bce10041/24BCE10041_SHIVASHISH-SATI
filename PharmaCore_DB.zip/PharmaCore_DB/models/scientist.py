from pydantic import BaseModel

class Scientist(BaseModel):
    name: str
    specialization: str
    qualification: str
    experience_years: int
    email: str
    phone: str