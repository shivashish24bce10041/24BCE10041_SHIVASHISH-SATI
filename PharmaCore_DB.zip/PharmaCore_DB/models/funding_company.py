from pydantic import BaseModel

class FundingCompany(BaseModel):
    company_name: str
    industry: str
    country: str
    contact_email: str