from fastapi import FastAPI
from database.connection import db
from models.molecule import Molecule
from models.scientist import Scientist
from models.research_team import ResearchTeam
from models.trial_phase import TrialPhase
from models.funding_company import FundingCompany
from models.funding_grant import FundingGrant
from models.regulatory_body import RegulatoryBody
from models.adverse_event import AdverseEvent
from bson import ObjectId


app = FastAPI()                 # This create an actual web application and the app represent the whole api server

molecule_collection = db["molecules"] # Selects the 'molecules' collection from pharmacore_db.
                                      # MongoDB will create it automatically when the first document is inserted.
scientist_collection = db["scientists"]

research_team_collection = db["research_teams"]

trial_phase_collection = db["trial_phases"]

funding_company_collection = db["funding_companies"]

funding_grant_collection = db["funding_grants"]

regulatory_body_collection = db["regulatory_bodies"]

adverse_event_collection = db["adverse_events"]

@app.get("/")
#     |  
#. The is a decorator and it tells FastAPI that when some one send a GET request  to "/". To return the function bellow
# "/" means --> http://127.0.0.1:8000/

def home():        # This is the function that return the following string. when someone visits:http://127.0.0.1:8000/
    return{"status":"Done!"}


#    " main:app --reload". :-This run the web app from terminal 


@app.post("/molecule")                      # A post request is send to the molecule 
def create_molecules(molecule:Molecule):    # recive a molecule object 
    molecule_dict = molecule.model_dump()   # Convert the object to directory 
    result = molecule_collection.insert_one(molecule_dict)      #insert the directorty to MongoDB

    return{                                 # get back the id that has been assigned to that directory 
        "message":"Inserted successfully",
        "id":str(result.inserted_id)
    }



@app.get("/molecules")                      # Creates a GET endpoint: http://127.0.0.1:8000/molecules
def get_molecules():                        # this run when ever some one send a get request to the  /molecules 

    molecules = list(molecule_collection.find()) # This will get us all the documents but .find() gives it in the form of cluster     
                                                 # hence we have to convert it into list so fast api can work with it 

    for molecule in molecules:                      # Loops througt all the  document in the moelcule 
        molecule["_id"] = str(molecule["_id"])      # And this convert this to the the JSON friendly format 

    return molecules                                # And this return the list 


@app.put("/molecule/{id}")
def update_molecule(id: str, molecule: Molecule):

    molecule_dict = molecule.model_dump()

    result = molecule_collection.update_one(
        {"_id": ObjectId(id)},
        {"$set": molecule_dict}
    )

    return {
        "message": "Molecule Updated Successfully",
        "modified_count": result.modified_count
    }

@app.delete("/molecule/{id}")
def delete_molecule(id: str):

    result = molecule_collection.delete_one(
        {"_id": ObjectId(id)}
    )

    return {
        "message": "Molecule Deleted Successfully",
        "deleted_count": result.deleted_count
    }

@app.post("/scientist")
def create_scientist(scientist: Scientist):

    scientist_dict = scientist.model_dump()

    result = scientist_collection.insert_one(scientist_dict)

    return {
        "message": "Scientist Inserted Successfully",
        "id": str(result.inserted_id)
    }
@app.get("/scientists")
def get_scientists():

    scientists = list(scientist_collection.find())

    for scientist in scientists:
        scientist["_id"] = str(scientist["_id"])

    return scientists
@app.put("/scientist/{id}")
def update_scientist(id: str, scientist: Scientist):

    scientist_dict = scientist.model_dump()

    result = scientist_collection.update_one(
        {"_id": ObjectId(id)},
        {"$set": scientist_dict}
    )

    return {
        "message": "Scientist Updated Successfully",
        "modified_count": result.modified_count
    }
@app.delete("/scientist/{id}")
def delete_scientist(id: str):

    result = scientist_collection.delete_one(
        {"_id": ObjectId(id)}
    )

    return {
        "message": "Scientist Deleted Successfully",
        "deleted_count": result.deleted_count
    }

@app.post("/team")
def create_team(team: ResearchTeam):

    team_dict = team.model_dump()

    result = research_team_collection.insert_one(team_dict)

    return {
        "message": "Team Created Successfully",
        "id": str(result.inserted_id)
    }
@app.get("/teams")
def get_teams():

    teams = list(research_team_collection.find())

    for team in teams:
        team["_id"] = str(team["_id"])

    return teams
@app.put("/team/{id}")
def update_team(id: str, team: ResearchTeam):

    team_dict = team.model_dump()

    result = research_team_collection.update_one(
        {"_id": ObjectId(id)},
        {"$set": team_dict}
    )

    return {
        "message": "Team Updated Successfully",
        "modified_count": result.modified_count
    }
@app.delete("/team/{id}")
def delete_team(id: str):

    result = research_team_collection.delete_one(
        {"_id": ObjectId(id)}
    )

    return {
        "message": "Team Deleted Successfully",
        "deleted_count": result.deleted_count
    }

@app.post("/trialphase")
def create_trial_phase(trial_phase: TrialPhase):

    trial_phase_dict = trial_phase.model_dump()

    result = trial_phase_collection.insert_one(trial_phase_dict)

    return {
        "message": "Trial Phase Created Successfully",
        "id": str(result.inserted_id)
    }


@app.get("/trialphases")
def get_trial_phases():

    trial_phases = list(trial_phase_collection.find())

    for phase in trial_phases:
        phase["_id"] = str(phase["_id"])

    return trial_phases


@app.put("/trialphase/{id}")
def update_trial_phase(id: str, trial_phase: TrialPhase):

    trial_phase_dict = trial_phase.model_dump()

    result = trial_phase_collection.update_one(
        {"_id": ObjectId(id)},
        {"$set": trial_phase_dict}
    )

    return {
        "message": "Trial Phase Updated Successfully",
        "modified_count": result.modified_count
    }


@app.delete("/trialphase/{id}")
def delete_trial_phase(id: str):

    result = trial_phase_collection.delete_one(
        {"_id": ObjectId(id)}
    )

    return {
        "message": "Trial Phase Deleted Successfully",
        "deleted_count": result.deleted_count
    }
@app.post("/fundingcompany")
def create_funding_company(company: FundingCompany):

    company_dict = company.model_dump()

    result = funding_company_collection.insert_one(company_dict)

    return {
        "message": "Funding Company Created Successfully",
        "id": str(result.inserted_id)
    }


@app.get("/fundingcompanies")
def get_funding_companies():

    companies = list(funding_company_collection.find())

    for company in companies:
        company["_id"] = str(company["_id"])

    return companies


@app.put("/fundingcompany/{id}")
def update_funding_company(id: str, company: FundingCompany):

    company_dict = company.model_dump()

    result = funding_company_collection.update_one(
        {"_id": ObjectId(id)},
        {"$set": company_dict}
    )

    return {
        "message": "Funding Company Updated Successfully",
        "modified_count": result.modified_count
    }


@app.delete("/fundingcompany/{id}")
def delete_funding_company(id: str):

    result = funding_company_collection.delete_one(
        {"_id": ObjectId(id)}
    )

    return {
        "message": "Funding Company Deleted Successfully",
        "deleted_count": result.deleted_count
    }

@app.post("/grant")
def create_grant(grant: FundingGrant):

    grant_dict = grant.model_dump()

    result = funding_grant_collection.insert_one(grant_dict)

    return {
        "message": "Grant Created Successfully",
        "id": str(result.inserted_id)
    }


@app.get("/grants")
def get_grants():

    grants = list(funding_grant_collection.find())

    for grant in grants:
        grant["_id"] = str(grant["_id"])

    return grants


@app.put("/grant/{id}")
def update_grant(id: str, grant: FundingGrant):

    grant_dict = grant.model_dump()

    result = funding_grant_collection.update_one(
        {"_id": ObjectId(id)},
        {"$set": grant_dict}
    )

    return {
        "message": "Grant Updated Successfully",
        "modified_count": result.modified_count
    }


@app.delete("/grant/{id}")
def delete_grant(id: str):

    result = funding_grant_collection.delete_one(
        {"_id": ObjectId(id)}
    )

    return {
        "message": "Grant Deleted Successfully",
        "deleted_count": result.deleted_count
    }
@app.post("/regulatorybody")
def create_regulatory_body(body: RegulatoryBody):

    body_dict = body.model_dump()

    result = regulatory_body_collection.insert_one(body_dict)

    return {
        "message": "Regulatory Body Created Successfully",
        "id": str(result.inserted_id)
    }


@app.get("/regulatorybodies")
def get_regulatory_bodies():

    bodies = list(regulatory_body_collection.find())

    for body in bodies:
        body["_id"] = str(body["_id"])

    return bodies


@app.put("/regulatorybody/{id}")
def update_regulatory_body(id: str, body: RegulatoryBody):

    body_dict = body.model_dump()

    result = regulatory_body_collection.update_one(
        {"_id": ObjectId(id)},
        {"$set": body_dict}
    )

    return {
        "message": "Regulatory Body Updated Successfully",
        "modified_count": result.modified_count
    }


@app.delete("/regulatorybody/{id}")
def delete_regulatory_body(id: str):

    result = regulatory_body_collection.delete_one(
        {"_id": ObjectId(id)}
    )

    return {
        "message": "Regulatory Body Deleted Successfully",
        "deleted_count": result.deleted_count
    }
@app.post("/adverseevent")
def create_adverse_event(event: AdverseEvent):

    event_dict = event.model_dump()

    result = adverse_event_collection.insert_one(event_dict)

    return {
        "message": "Adverse Event Created Successfully",
        "id": str(result.inserted_id)
    }


@app.get("/adverseevents")
def get_adverse_events():

    events = list(adverse_event_collection.find())

    for event in events:
        event["_id"] = str(event["_id"])

    return events


@app.put("/adverseevent/{id}")
def update_adverse_event(id: str, event: AdverseEvent):

    event_dict = event.model_dump()

    result = adverse_event_collection.update_one(
        {"_id": ObjectId(id)},
        {"$set": event_dict}
    )

    return {
        "message": "Adverse Event Updated Successfully",
        "modified_count": result.modified_count
    }


@app.delete("/adverseevent/{id}")
def delete_adverse_event(id: str):

    result = adverse_event_collection.delete_one(
        {"_id": ObjectId(id)}
    )

    return {
        "message": "Adverse Event Deleted Successfully",
        "deleted_count": result.deleted_count
    }